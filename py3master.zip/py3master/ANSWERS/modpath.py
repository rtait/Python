#!/usr/bin/env python

import sys
for path in sorted(sys.path):
    print(path)

