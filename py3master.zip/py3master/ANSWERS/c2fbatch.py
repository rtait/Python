#!/usr/bin/env python

import sys

c = float(sys.argv[1])

f = ((9 * c) / 5 ) + 32

print("{0:.1f} C is {1:.1f} F".format(c,f))

