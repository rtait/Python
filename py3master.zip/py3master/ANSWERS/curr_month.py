#!/usr/bin/env python
"""

@author: jstrick
Created on Wed Mar 20 21:27:45 2013

"""
import calendar

tc = calendar.TextCalendar()
tc.prmonth(2013, 9)
