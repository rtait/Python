#!/usr/bin/env python
# (c)2015 John Strickler

from montylib import spam, ham, _eggs

spam()
ham()
_eggs()

