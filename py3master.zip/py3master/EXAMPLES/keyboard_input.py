#!/usr/bin/env python
n = input("What is your name: ")
q = input("What is your quest? ")
print(n, "seeks", q)
raw_num = input("Enter number: ")
num = int(raw_num)
print("2 times", num, "is ", 2 * num)
