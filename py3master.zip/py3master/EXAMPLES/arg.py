#!/usr/bin/env python

import sys
name = sys.argv[1]
print("name is", name)
