#!/usr/bin/env python
# (c)2015 John Strickler

import montylib

montylib.spam()
montylib.ham()
montylib._eggs()

