#!/usr/bin/env python
import sys

print(sys.argv)

name = sys.argv[1]
print("name is",name)
