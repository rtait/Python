#!/usr/bin/env python
# (c)2015 John Strickler

def spam():
    print("Hello from spam()")

def ham():
    print("Hello from ham()")

def _eggs():
    print("Hello from _eggs()")

