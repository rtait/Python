#!/usr/bin/env python
x = 5
x += 10
y = 22
y *= 3
z = 98.7
print("x is ", x)
print("y is ", y)
print("2^16", 2**16)
print("x / y", x/y)
print("x // y", x//y)
print("x / z", x/z)
print("x // z", x//z)
