#!/usr/bin/env python

import foolib
foolib.hello()
foolib.shush()