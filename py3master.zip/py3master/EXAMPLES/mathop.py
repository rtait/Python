#!/usr/bin/env python
x = 5
x += 10
print("x is ",x)
y = 22.7
y *= 3
print("y is ",y)
print("2^16",2**16)
print("x / y",x/y)
print("x // y",x//y)
print("y / x",y/x)
print("y // x",y//x)
